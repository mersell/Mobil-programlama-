package com.example.array;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    Button btnGenerate1, btnGenerate2;
    TextView txtArray, txtMax, txtMin, txtAvg;
    TextView txtAll, txtEven, txtOdd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnGenerate1 = findViewById(R.id.btnGenerate1);
        btnGenerate2 = findViewById(R.id.btnGenerate2);

        txtArray = findViewById(R.id.txtArray);
        txtMax = findViewById(R.id.txtMax);
        txtMin = findViewById(R.id.txtMin);
        txtAvg = findViewById(R.id.txtAvg);

        txtAll = findViewById(R.id.txtAll);
        txtEven = findViewById(R.id.txtEven);
        txtOdd = findViewById(R.id.txtOdd);

        btnGenerate1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int[] arr = new int[10];
                Random r = new Random();

                int sum = 0;
                int max = Integer.MIN_VALUE;
                int min = Integer.MAX_VALUE;

                String arrayStr = "";

                for (int i = 0; i < arr.length; i++) {
                    arr[i] = r.nextInt(100);
                    sum += arr[i];

                    if (arr[i] > max) max = arr[i];
                    if (arr[i] < min) min = arr[i];

                    arrayStr += arr[i] + " ";
                }

                double avg = sum / 10.0;

                txtArray.setText("Dizinin kendisi: " + arrayStr);
                txtMax.setText("En Büyük: " + max);
                txtMin.setText("En Küçük: " + min);
                txtAvg.setText("Ortalama: " + avg);
            }
        });

        btnGenerate2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int[] arr = new int[10];
                Random r = new Random();

                String all = "";
                String even = "";
                String odd = "";

                for (int i = 0; i < arr.length; i++) {
                    arr[i] = r.nextInt(100);
                    all += arr[i] + " ";

                    if (arr[i] % 2 == 0) {
                        even += arr[i] + " ";
                    } else {
                        odd += arr[i] + " ";
                    }
                }

                txtAll.setText("Dizi: " + all);
                txtEven.setText("Çift Sayılar: " + even);
                txtOdd.setText("Tek Sayılar: " + odd);
            }
        });
    }
}