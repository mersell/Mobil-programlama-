package com.example.myapplication;

import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    RadioGroup radioGroup;
    Button btnsecim;
    TextView textsonuc;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        radioGroup=findViewById(R.id.radioGroup);
        btnsecim=findViewById(R.id.btnsecim);
        textsonuc=findViewById(R.id.textsonuc);
        btnsecim.setOnClickListener(v->{
            int secilenId =radioGroup.getCheckedRadioButtonId();
            if(secilenId==-1){
                textsonuc.setText("seçim yapılmadı");
            }else {
                RadioButton secilen =findViewById(secilenId);
                textsonuc.setText("seçilen"+secilen.getText().toString());
            }
        });
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}