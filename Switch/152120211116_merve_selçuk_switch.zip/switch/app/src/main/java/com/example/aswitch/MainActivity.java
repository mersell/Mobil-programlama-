package com.example.aswitch;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.CompoundButton;

public class MainActivity extends AppCompatActivity {

    Switch switchNotif, switchSound;
    TextView txtStatus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        switchNotif = findViewById(R.id.switchNotif);
        switchSound = findViewById(R.id.switchSound);
        txtStatus = findViewById(R.id.txtStatus);

        CompoundButton.OnCheckedChangeListener listener = new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                updateStatus();
            }
        };

        switchNotif.setOnCheckedChangeListener(listener);
        switchSound.setOnCheckedChangeListener(listener);
    }

    private void updateStatus() {
        String notif = switchNotif.isChecked() ? "Açık" : "Kapalı";
        String sound = switchSound.isChecked() ? "Açık" : "Kapalı";

        txtStatus.setText("Bildirimler: " + notif + "\nSes: " + sound);
    }
}