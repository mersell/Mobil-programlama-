package com.example.myapplication;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private EditText etIsim, etSoyisim, etYas;
    private RadioGroup rgCinsiyet;
    private RadioButton rbKadin, rbErkek;
    private Button btnEkle, btnGuncelle, btnSil;
    private ListView listView;
    private TextView tvCinsiyetSayisi, tvYuzdeIstatistik;
    
    private ArrayList<kisi> kisiList;
    private ozeladapter adapter;
    private int seciliPozisyon = -1;
    private Database db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        db = new Database(this);

        etIsim = findViewById(R.id.etIsim);
        etSoyisim = findViewById(R.id.etSoyisim);
        etYas = findViewById(R.id.etYas);
        rgCinsiyet = findViewById(R.id.rgCinsiyet);
        rbKadin = findViewById(R.id.rbKadin);
        rbErkek = findViewById(R.id.rbErkek);
        btnEkle = findViewById(R.id.btnEkle);
        btnGuncelle = findViewById(R.id.btnGuncelle);
        btnSil = findViewById(R.id.btnSil);
        listView = findViewById(R.id.listView);
        tvCinsiyetSayisi = findViewById(R.id.tvCinsiyetSayisi);
        tvYuzdeIstatistik = findViewById(R.id.tvYuzdeIstatistik);

        kisiList = db.kisiler();
        adapter = new ozeladapter(this, kisiList);
        listView.setAdapter(adapter);
        istatistikGuncelle();

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                seciliPozisyon = position;
                kisi secilenKisi = kisiList.get(position);
                
                etIsim.setText(secilenKisi.getIsim());
                etSoyisim.setText(secilenKisi.getSoyisim());
                etYas.setText(String.valueOf(secilenKisi.getYas()));
                if (secilenKisi.isKadinmi()) {
                    rbKadin.setChecked(true);
                } else {
                    rbErkek.setChecked(true);
                }
            }
        });

        btnEkle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String isim = etIsim.getText().toString();
                String soyisim = etSoyisim.getText().toString();
                String yasStr = etYas.getText().toString();
                
                if (!isim.isEmpty() && !soyisim.isEmpty() && !yasStr.isEmpty()) {
                    int yas = Integer.parseInt(yasStr);
                    int cinsiyet = rbKadin.isChecked() ? 1 : 0;
                    db.kisiEkle(isim, soyisim, yas, cinsiyet);
                    verileriYenile();
                    temizle();
                } else {
                    Toast.makeText(MainActivity.this, "Lütfen tüm alanları doldurun", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnGuncelle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (seciliPozisyon != -1) {
                    String isim = etIsim.getText().toString();
                    String soyisim = etSoyisim.getText().toString();
                    String yasStr = etYas.getText().toString();
                    
                    if (!isim.isEmpty() && !soyisim.isEmpty() && !yasStr.isEmpty()) {
                        int yas = Integer.parseInt(yasStr);
                        int cinsiyet = rbKadin.isChecked() ? 1 : 0;
                        int id = kisiList.get(seciliPozisyon).getId();
                        db.kisiDuzenle(isim, soyisim, yas, cinsiyet, id);
                        verileriYenile();
                        temizle();
                        seciliPozisyon = -1;
                    }
                }
            }
        });

        btnSil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (seciliPozisyon != -1) {
                    db.kisiSil(kisiList.get(seciliPozisyon).getId());
                    verileriYenile();
                    temizle();
                    seciliPozisyon = -1;
                }
            }
        });
    }

    private void verileriYenile() {
        kisiList.clear();
        kisiList.addAll(db.kisiler());
        adapter.notifyDataSetChanged();
        istatistikGuncelle();
    }

    private void istatistikGuncelle() {
        int kadin = db.getKadinSayisi();
        int erkek = db.getErkekSayisi();
        tvCinsiyetSayisi.setText("Kadın: " + kadin + "   Erkek: " + erkek);

        int cocuk = db.getSayi(0, 0, 5) + db.getSayi(1, 0, 5);
        int yetiskin = db.getSayi(0, 5, 60) + db.getSayi(1, 5, 60);
        int yasli = db.getSayi(0, 60) + db.getSayi(1, 60);

        tvYuzdeIstatistik.setText("Çocuk: " + cocuk + "  Yetişkin: " + yetiskin + " Yaşlı: " + yasli);
    }

    private void temizle() {
        etIsim.setText("");
        etSoyisim.setText("");
        etYas.setText("");
        rgCinsiyet.clearCheck();
    }
}
