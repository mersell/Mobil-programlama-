package com.example.myapplication;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

public class ozeladapter extends BaseAdapter {
    private Context context;
    private List<kisi> kisiList;

    public ozeladapter(Context context, List<kisi> kisiList) {
        this.context = context;
        this.kisiList = kisiList;
    }

    @Override
    public int getCount() {
        return kisiList.size();
    }

    @Override
    public Object getItem(int position) {
        return kisiList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.satir_layout, parent, false);
        }

        kisi currentKisi = kisiList.get(position);

        ImageView imageView = convertView.findViewById(R.id.imageView);
        TextView tvIsimSoyisim = convertView.findViewById(R.id.isimsoyisim);
        TextView tvYas = convertView.findViewById(R.id.yas);

        tvIsimSoyisim.setText(currentKisi.getIsim() + " " + currentKisi.getSoyisim());
        tvYas.setText(String.valueOf(currentKisi.getYas()));

        int yas = currentKisi.getYas();
        if (currentKisi.isKadinmi()) {
            if (yas < 5) {
                imageView.setImageResource(R.drawable.kucukkiz);
            } else if (yas < 60) {
                imageView.setImageResource(R.drawable.yetsiskinkadin);
            } else {
                imageView.setImageResource(R.drawable.yaslikadin);
            }
        } else {
            if (yas < 5) {
                imageView.setImageResource(R.drawable.kucukerkek);
            } else if (yas < 60) {
                imageView.setImageResource(R.drawable.yetiskinerkek);
            } else {
                imageView.setImageResource(R.drawable.yaslierkek);
            }
        }
        
        imageView.setScaleX(1.0f);
        imageView.setScaleY(1.0f);
        imageView.setAlpha(1.0f);

        return convertView;
    }
}
