package com.example.myapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

public class Database extends SQLiteOpenHelper {

    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "rehber_db";

    private static final String TABLE_NAME = "kisi_listesi";
    private static String KISI_ID = "id";
    private static String KISI_ISIM = "isim";
    private static String KISI_SOYISIM = "soyisim";
    private static String KISI_YAS = "yas";
    private static String KISI_CINSIYET = "cinsiyet";

    public Database(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_TABLE = "CREATE TABLE " + TABLE_NAME + "("
                + KISI_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + KISI_ISIM + " TEXT,"
                + KISI_SOYISIM + " TEXT,"
                + KISI_YAS + " INTEGER,"
                + KISI_CINSIYET + " INTEGER" + ")";
        db.execSQL(CREATE_TABLE);
    }

    public void kisiSil(int id){
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_NAME, KISI_ID + " = ?",
                new String[] { String.valueOf(id) });
        db.close();
    }

    public void kisiEkle(String isim, String soyisim, int yas, int cinsiyet) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(KISI_ISIM, isim);
        values.put(KISI_SOYISIM, soyisim);
        values.put(KISI_YAS, yas);
        values.put(KISI_CINSIYET, cinsiyet);

        db.insert(TABLE_NAME, null, values);
        db.close();
    }

    public ArrayList<kisi> kisiler(){
        SQLiteDatabase db = this.getReadableDatabase();
        String selectQuery = "SELECT * FROM " + TABLE_NAME;
        Cursor cursor = db.rawQuery(selectQuery, null);
        ArrayList<kisi> kisilist = new ArrayList<kisi>();

        if (cursor.moveToFirst()) {
            do {
                kisi kisi = new kisi(
                        cursor.getString(1),
                        cursor.getString(2),
                        cursor.getInt(4) == 1,
                        cursor.getInt(3)
                );
                kisi.setId(cursor.getInt(0));
                kisilist.add(kisi);
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return kisilist;
    }

    public void kisiDuzenle(String isim, String soyisim, int yas, int cinsiyet, int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(KISI_ISIM, isim);
        values.put(KISI_SOYISIM, soyisim);
        values.put(KISI_YAS, yas);
        values.put(KISI_CINSIYET, cinsiyet);

        db.update(TABLE_NAME, values, KISI_ID + " = ?",
                new String[] { String.valueOf(id) });
        db.close();
    }

    public int getSayi(int cinsiyet, int minYas, int maxYas) {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT COUNT(*) FROM " + TABLE_NAME + " WHERE " + KISI_CINSIYET + "=" + cinsiyet + 
                       " AND " + KISI_YAS + " >= " + minYas + " AND " + KISI_YAS + " < " + maxYas;
        Cursor cursor = db.rawQuery(query, null);
        int count = 0;
        if (cursor.moveToFirst()) {
            count = cursor.getInt(0);
        }
        cursor.close();
        return count;
    }

    public int getSayi(int cinsiyet, int minYas) {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT COUNT(*) FROM " + TABLE_NAME + " WHERE " + KISI_CINSIYET + "=" + cinsiyet + 
                       " AND " + KISI_YAS + " >= " + minYas;
        Cursor cursor = db.rawQuery(query, null);
        int count = 0;
        if (cursor.moveToFirst()) {
            count = cursor.getInt(0);
        }
        cursor.close();
        return count;
    }

    public int getKadinSayisi() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT COUNT(*) FROM " + TABLE_NAME + " WHERE " + KISI_CINSIYET + "=1", null);
        int count = 0;
        if (cursor.moveToFirst()) {
            count = cursor.getInt(0);
        }
        cursor.close();
        return count;
    }

    public int getErkekSayisi() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT COUNT(*) FROM " + TABLE_NAME + " WHERE " + KISI_CINSIYET + "=0", null);
        int count = 0;
        if (cursor.moveToFirst()) {
            count = cursor.getInt(0);
        }
        cursor.close();
        return count;
    }

    @Override
    public void onUpgrade(SQLiteDatabase arg0, int arg1, int arg2) {
    }
}
