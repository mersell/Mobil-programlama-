package com.example.myapplication;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private EditText etIsim, etSoyisim, etYas;
    private RadioGroup rgCinsiyet;
    private RadioButton rbKadin, rbErkek;
    private Button btnEkle, btnGuncelle, btnSil;
    private ListView listView;
    
    private List<kisi> kisiList;
    private ozeladapter adapter;
    private int seciliPozisyon = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etIsim = findViewById(R.id.etIsim);
        etSoyisim = findViewById(R.id.etSoyisim);
        etYas = findViewById(R.id.etYas);
        rgCinsiyet = findViewById(R.id.rgCinsiyet);
        rbKadin = findViewById(R.id.rbKadin);
        rbErkek = findViewById(R.id.rbErkek);
        btnEkle = findViewById(R.id.btnEkle);
        btnGuncelle = findViewById(R.id.btnGuncelle);
        btnSil = findViewById(R.id.btnSil);
        listView = findViewById(R.id.listView);

        kisiList = new ArrayList<>();
        adapter = new ozeladapter(this, kisiList);
        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                seciliPozisyon = position;
                kisi secilenKisi = kisiList.get(position);
                
                etIsim.setText(secilenKisi.getIsim());
                etSoyisim.setText(secilenKisi.getSoyisim());
                etYas.setText(String.valueOf(secilenKisi.getYas()));
                if (secilenKisi.isKadinmi()) {
                    rbKadin.setChecked(true);
                } else {
                    rbErkek.setChecked(true);
                }
            }
        });

        btnEkle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String isim = etIsim.getText().toString();
                String soyisim = etSoyisim.getText().toString();
                String yasStr = etYas.getText().toString();
                
                if (!isim.isEmpty() && !soyisim.isEmpty() && !yasStr.isEmpty()) {
                    int yas = Integer.parseInt(yasStr);
                    boolean kadinmi = rbKadin.isChecked();
                    
                    kisiList.add(new kisi(isim, soyisim, kadinmi, yas));
                    adapter.notifyDataSetChanged();
                    temizle();
                } else {
                    Toast.makeText(MainActivity.this, "Lütfen tüm alanları doldurun", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnGuncelle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (seciliPozisyon != -1) {
                    String isim = etIsim.getText().toString();
                    String soyisim = etSoyisim.getText().toString();
                    String yasStr = etYas.getText().toString();
                    
                    if (!isim.isEmpty() && !soyisim.isEmpty() && !yasStr.isEmpty()) {
                        int yas = Integer.parseInt(yasStr);
                        boolean kadinmi = rbKadin.isChecked();
                        
                        kisi guncelKisi = kisiList.get(seciliPozisyon);
                        guncelKisi.setIsim(isim);
                        guncelKisi.setSoyisim(soyisim);
                        guncelKisi.setYas(yas);
                        guncelKisi.setKadinmi(kadinmi);
                        
                        adapter.notifyDataSetChanged();
                        temizle();
                        seciliPozisyon = -1;
                    }
                } else {
                    Toast.makeText(MainActivity.this, "Güncellemek için listeden birini seçin", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnSil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (seciliPozisyon != -1) {
                    kisiList.remove(seciliPozisyon);
                    adapter.notifyDataSetChanged();
                    temizle();
                    seciliPozisyon = -1;
                } else {
                    Toast.makeText(MainActivity.this, "Silmek için listeden birini seçin", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void temizle() {
        etIsim.setText("");
        etSoyisim.setText("");
        etYas.setText("");
        rgCinsiyet.clearCheck();
    }
}
