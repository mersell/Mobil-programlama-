package com.example.myapplication;

public class kisi {
    private String isim;
    private String soyisim;
    private boolean kadinmi;
    private int yas;

    public kisi(String isim, String soyisim, boolean kadinmi, int yas) {
        this.isim = isim;
        this.soyisim = soyisim;
        this.kadinmi = kadinmi;
        this.yas = yas;
    }

    public String getIsim() {
        return isim;
    }

    public void setIsim(String isim) {
        this.isim = isim;
    }

    public String getSoyisim() {
        return soyisim;
    }

    public void setSoyisim(String soyisim) {
        this.soyisim = soyisim;
    }

    public boolean isKadinmi() {
        return kadinmi;
    }

    public void setKadinmi(boolean kadinmi) {
        this.kadinmi = kadinmi;
    }

    public int getYas() {
        return yas;
    }

    public void setYas(int yas) {
        this.yas = yas;
    }
}
