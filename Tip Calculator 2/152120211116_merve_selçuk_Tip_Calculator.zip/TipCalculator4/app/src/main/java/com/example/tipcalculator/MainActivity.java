package com.example.tipcalculator;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    EditText corbaAdet, yemekAdet, tatliAdet;
    TextView corbaToplam, yemekToplam, tatliToplam;
    TextView sonucYemek, sonucBahsis, sonucHesap;
    Button hesaplaButon;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        corbaAdet = findViewById(R.id.etCorbaAdet);
        yemekAdet = findViewById(R.id.etAnaYemekAdet);
        tatliAdet = findViewById(R.id.etTatliAdet);

        corbaToplam = findViewById(R.id.tvCorbaToplam);
        yemekToplam = findViewById(R.id.tvAnaYemekToplam);
        tatliToplam = findViewById(R.id.tvTatliToplam);

        sonucYemek = findViewById(R.id.tvSonucYemek);
        sonucBahsis = findViewById(R.id.tvSonucBahsis);
        sonucHesap = findViewById(R.id.tvSonucGenel);

        hesaplaButon = findViewById(R.id.btnHesapla);

        hesaplaButon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                double cFiyat = 0;
                double yFiyat = 0;
                double tFiyat = 0;

                if (!corbaAdet.getText().toString().equals("")) {
                    cFiyat = Integer.parseInt(corbaAdet.getText().toString()) * 4.5;
                }
                if (!yemekAdet.getText().toString().equals("")) {
                    yFiyat = Integer.parseInt(yemekAdet.getText().toString()) * 7.4;
                }
                if (!tatliAdet.getText().toString().equals("")) {
                    tFiyat = Integer.parseInt(tatliAdet.getText().toString()) * 5.3;
                }

                corbaToplam.setText("Toplam Fiyat: " + cFiyat + " TL");
                yemekToplam.setText("Toplam Fiyat: " + yFiyat + " TL");
                tatliToplam.setText("Toplam Fiyat: " + tFiyat + " TL");

                double toplamYemek = cFiyat + yFiyat + tFiyat;
                double bahsis = toplamYemek * 0.05;
                double genelToplam = toplamYemek + bahsis;

                sonucYemek.setText("Toplam Yemek: " + toplamYemek + " TL");
                sonucBahsis.setText("Toplam Bahşiş (%5): " + bahsis + " TL");
                sonucHesap.setText("Toplam Hesap: " + genelToplam + " TL");
            }
        });
    }
}