package com.example.myapplication1;

import android.graphics.Color;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import androidx.appcompat.widget.SwitchCompat; // SwitchCompat kullanmalısın
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

public class MainActivity extends AppCompatActivity {

    EditText etSifre;
    Button btnGosterGizle;
    SwitchCompat switch1; // SwitchCompat olarak güncelledik
    ConstraintLayout anaLayout;
    boolean sifregormu = false;

    CheckBox cBox, cBox2;
    RadioGroup rgCinsiyet;
    Button button3;
    TextView txt4, txt2, txt3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // --- BAĞLAMA İŞLEMLERİ (Buradaki eksikler çökme sebebiydi) ---
        anaLayout = findViewById(R.id.anaLayout); // EKSİKTİ, EKLENDİ
        etSifre = findViewById(R.id.etSifre);
        btnGosterGizle = findViewById(R.id.btnGosterGizle);
        cBox = findViewById(R.id.cBox);
        cBox2 = findViewById(R.id.cBox2);
        rgCinsiyet = findViewById(R.id.rgCinsiyet);
        button3 = findViewById(R.id.button3);
        txt4 = findViewById(R.id.txt4);
        txt2 = findViewById(R.id.txt2); // EKSİKTİ, EKLENDİ
        txt3 = findViewById(R.id.txt3); // EKSİKTİ, EKLENDİ
        switch1 = findViewById(R.id.switch1);

        // --- ŞİFRE GİZLE / GÖSTER ---
        btnGosterGizle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (sifregormu) {
                    etSifre.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
                    btnGosterGizle.setText("Şifreyi Göster");
                    sifregormu = false;
                } else {
                    etSifre.setInputType(InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
                    btnGosterGizle.setText("Şifreyi Gizle");
                    sifregormu = true;
                }
                etSifre.setSelection(etSifre.getText().length());
            }
        });

        // --- GECE / GÜNDÜZ MODU ---
        switch1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(@NonNull CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    anaLayout.setBackgroundColor(Color.parseColor("#212121"));
                    switch1.setTextColor(Color.WHITE);
                    txt2.setTextColor(Color.WHITE);
                    txt3.setTextColor(Color.WHITE);
                    txt4.setTextColor(Color.WHITE);
                    cBox.setTextColor(Color.WHITE);  // Yazıları da beyaz yapalım
                    cBox2.setTextColor(Color.WHITE);
                } else {
                    anaLayout.setBackgroundColor(Color.WHITE);
                    switch1.setTextColor(Color.BLACK);
                    txt2.setTextColor(Color.BLACK);
                    txt3.setTextColor(Color.BLACK);
                    txt4.setTextColor(Color.BLACK);
                    cBox.setTextColor(Color.BLACK);
                    cBox2.setTextColor(Color.BLACK);
                }
            }
        });

        // --- SONUÇLARI GÖSTER ---
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                StringBuilder sonucMesaji = new StringBuilder();
                sonucMesaji.append("Bildiğiniz Diller: ");
                if (cBox.isChecked()) sonucMesaji.append("Java ");
                if (cBox2.isChecked()) sonucMesaji.append("C# ");
                if (!cBox.isChecked() && !cBox2.isChecked()) sonucMesaji.append("Seçilmedi");

                sonucMesaji.append("\n");

                int secilenId = rgCinsiyet.getCheckedRadioButtonId();
                if (secilenId != -1) {
                    RadioButton secilenRadio = findViewById(secilenId);
                    sonucMesaji.append("Cinsiyet: ").append(secilenRadio.getText());
                } else {
                    sonucMesaji.append("Cinsiyet: Seçilmedi");
                }
                txt4.setText(sonucMesaji.toString());
            }
        });
    }
}