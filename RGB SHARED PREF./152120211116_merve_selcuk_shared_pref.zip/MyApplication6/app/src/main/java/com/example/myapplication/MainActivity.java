package com.example.myapplication;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

public class MainActivity extends AppCompatActivity {

    EditText etRed, etGreen, etBlue;
    Button btnKaydet;
    ConstraintLayout anaLayout;
    SharedPreferences sharedPref;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etRed = findViewById(R.id.etRed);
        etGreen = findViewById(R.id.etGreen);
        etBlue = findViewById(R.id.etBlue);
        btnKaydet = findViewById(R.id.btnUygula);
        anaLayout = findViewById(R.id.main);

        sharedPref = getSharedPreferences("RenkKayit", Context.MODE_PRIVATE);

        int r = sharedPref.getInt("kırmızı", 255);
        int g = sharedPref.getInt("yeşil", 255);
        int b = sharedPref.getInt("mavi", 255);

        anaLayout.setBackgroundColor(Color.rgb(r, g, b));
        etRed.setText(String.valueOf(r));
        etGreen.setText(String.valueOf(g));
        etBlue.setText(String.valueOf(b));

        btnKaydet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String sR = etRed.getText().toString();
                String sG = etGreen.getText().toString();
                String sB = etBlue.getText().toString();

                if (!sR.isEmpty() && !sG.isEmpty() && !sB.isEmpty()) {
                    int valR = Integer.parseInt(sR);
                    int valG = Integer.parseInt(sG);
                    int valB = Integer.parseInt(sB);

                    SharedPreferences.Editor editor = sharedPref.edit();
                    editor.putInt("kırmızı", valR);
                    editor.putInt("yeşl", valG);
                    editor.putInt("mavi", valB);
                    editor.apply();

                    anaLayout.setBackgroundColor(Color.rgb(valR, valG, valB));
                }
            }
        });
    }
}