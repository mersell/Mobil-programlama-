package com.example.myapplication;

import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

public class MainActivity extends AppCompatActivity {

    private EditText etRoomLabel, etUserName;
    private Switch swPower, swDarkMode, swTemp, swCurtain, swSpecial;
    private CheckBox cbSafety;
    private ImageView imgRoomIcon, btnSelectMutfak, btnSelectSalon, btnSelectYatak, btnSelectBanyo;
    private Button btnSaveSettings, btnEnterApp, btnBack, btnBackToWelcome;
    private TextView lblInfoLog, txtWelcomeTitle, lblMode, txtUserGreeting, lblTempDegree, txtInRoomUser, txtDangerAlert;
    private TextView txtSummaryLights, txtSummaryTemp, txtSummarySafety;
    private LinearLayout layoutDashboard;
    private ConstraintLayout layoutWelcome, layoutRoomSelection, layoutMain, rootLayout;

    private SharedPreferences sharedPref;
    private String currentRoom = "";
    private String userName = "";
    private final Handler dangerHandler = new Handler();
    private boolean isRed = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // --- NESNE BAĞLANTILARI ---
        rootLayout = findViewById(R.id.rootLayout);
        layoutWelcome = findViewById(R.id.layoutWelcome);
        layoutRoomSelection = findViewById(R.id.layoutRoomSelection);
        layoutMain = findViewById(R.id.layoutMain);
        layoutDashboard = findViewById(R.id.layoutDashboard);
        swDarkMode = findViewById(R.id.swDarkMode);
        btnEnterApp = findViewById(R.id.btnEnterApp);
        btnBack = findViewById(R.id.btnBack);
        btnBackToWelcome = findViewById(R.id.btnBackToWelcome);
        txtWelcomeTitle = findViewById(R.id.txtWelcomeTitle);
        txtUserGreeting = findViewById(R.id.txtUserGreeting);
        lblMode = findViewById(R.id.lblMode);
        lblTempDegree = findViewById(R.id.lblTempDegree);
        swTemp = findViewById(R.id.swTemp);
        swCurtain = findViewById(R.id.swCurtain);
        swSpecial = findViewById(R.id.swSpecial);
        etUserName = findViewById(R.id.etUserName);
        txtInRoomUser = findViewById(R.id.txtInRoomUser);
        txtDangerAlert = findViewById(R.id.txtDangerAlert);
        txtSummaryLights = findViewById(R.id.txtSummaryLights);
        txtSummaryTemp = findViewById(R.id.txtSummaryTemp);
        txtSummarySafety = findViewById(R.id.txtSummarySafety);
        btnSelectMutfak = findViewById(R.id.btnSelectMutfak);
        btnSelectSalon = findViewById(R.id.btnSelectSalon);
        btnSelectYatak = findViewById(R.id.btnSelectYatak);
        btnSelectBanyo = findViewById(R.id.btnSelectBanyo);
        etRoomLabel = findViewById(R.id.etRoomLabel);
        swPower = findViewById(R.id.swPower);
        cbSafety = findViewById(R.id.cbSafety);
        imgRoomIcon = findViewById(R.id.imgRoomIcon);
        btnSaveSettings = findViewById(R.id.btnSaveSettings);
        lblInfoLog = findViewById(R.id.lblInfoLog);

        sharedPref = getSharedPreferences("SmartHomePrefs", MODE_PRIVATE);
        userName = sharedPref.getString("user_name", "");
        if (!userName.isEmpty()) etUserName.setText(userName);

        // --- SAYFA GEÇİŞLERİ ---
        btnEnterApp.setOnClickListener(v -> {
            String name = etUserName.getText().toString();
            if (!name.isEmpty()) {
                userName = name;
                sharedPref.edit().putString("user_name", userName).apply();
                txtUserGreeting.setText("Hoş geldin " + userName + "!");
                layoutWelcome.setVisibility(View.GONE);
                layoutRoomSelection.setVisibility(View.VISIBLE);
                updateDashboard();
                checkDanger();
            }
        });

        btnBackToWelcome.setOnClickListener(v -> {
            layoutRoomSelection.setVisibility(View.GONE);
            layoutWelcome.setVisibility(View.VISIBLE);
            dangerHandler.removeCallbacksAndMessages(null);
        });

        btnBack.setOnClickListener(v -> {
            layoutMain.setVisibility(View.GONE);
            layoutRoomSelection.setVisibility(View.VISIBLE);
            updateDashboard();
            checkDanger();
        });

        btnSelectMutfak.setOnClickListener(v -> openRoomPanel("Mutfak"));
        btnSelectSalon.setOnClickListener(v -> openRoomPanel("Salon"));
        btnSelectYatak.setOnClickListener(v -> openRoomPanel("Yatak Odası"));
        btnSelectBanyo.setOnClickListener(v -> openRoomPanel("Banyo"));

        // --- KARANLIK MOD (TAM ÇÖZÜM) ---
        swDarkMode.setOnCheckedChangeListener((bv, isChecked) -> {
            int textColor = isChecked ? Color.WHITE : Color.BLACK;
            int panelColor = isChecked ? Color.parseColor("#2C2C2C") : Color.WHITE;

            rootLayout.setBackgroundColor(isChecked ? Color.parseColor("#121212") : Color.parseColor("#ECEFF1"));
            layoutDashboard.setBackgroundColor(panelColor);

            // Dashboard Yazıları
            txtSummaryLights.setTextColor(textColor);
            txtSummaryTemp.setTextColor(textColor);
            txtSummarySafety.setTextColor(textColor);

            // Tüm Metinleri Güncelle
            txtWelcomeTitle.setTextColor(textColor);
            lblMode.setTextColor(textColor);
            txtUserGreeting.setTextColor(textColor);
            txtInRoomUser.setTextColor(textColor);
            lblTempDegree.setTextColor(textColor);
            lblInfoLog.setTextColor(textColor);
            swPower.setTextColor(textColor);
            swTemp.setTextColor(textColor);
            swCurtain.setTextColor(textColor);
            swSpecial.setTextColor(textColor);
            cbSafety.setTextColor(textColor);
            etUserName.setTextColor(textColor);
            etRoomLabel.setTextColor(textColor);
            lblMode.setText("MOD");
        });

        swPower.setOnCheckedChangeListener((bv, isChecked) -> updateHomeVisuals());
        swCurtain.setOnCheckedChangeListener((bv, isChecked) -> updateHomeVisuals());
        swTemp.setOnCheckedChangeListener((bv, isChecked) -> lblTempDegree.setText(isChecked ? "26°C" : "22°C"));

        btnSaveSettings.setOnClickListener(v -> saveRoomData(currentRoom));
    }

    private void openRoomPanel(String roomName) {
        currentRoom = roomName;
        layoutRoomSelection.setVisibility(View.GONE);
        layoutMain.setVisibility(View.VISIBLE);
        txtInRoomUser.setText(userName + ", şu an " + roomName + " yönetiliyor.");
        swSpecial.setVisibility(View.VISIBLE);
        if (roomName.equals("Mutfak")) { imgRoomIcon.setImageResource(R.drawable.mutfak); swSpecial.setText("Ocak"); }
        else if (roomName.equals("Banyo")) { imgRoomIcon.setImageResource(R.drawable.banyo); swSpecial.setText("Su Vanası"); }
        else if (roomName.equals("Salon")) { imgRoomIcon.setImageResource(R.drawable.indir); swSpecial.setText("Klima"); }
        else { imgRoomIcon.setImageResource(R.drawable.yatak); swSpecial.setVisibility(View.GONE); }
        loadRoomData(roomName);
    }

    private void updateDashboard() {
        String[] rooms = {"Mutfak", "Salon", "Yatak Odası", "Banyo"};
        int lights = 0, tempTotal = 0; boolean safety = false;
        for (String r : rooms) {
            if (sharedPref.getBoolean(r + "_power", false)) lights++;
            tempTotal += (sharedPref.getBoolean(r + "_temp", false) ? 26 : 22);
            if (sharedPref.getBoolean(r + "_safety", false)) safety = true;
        }
        txtSummaryLights.setText("💡 " + lights + " odada ışıklar açık.");
        txtSummaryTemp.setText("🌡️ Ortalama Sıcaklık: " + (tempTotal / 4) + "°C");
        txtSummarySafety.setText("🛡️ Güvenlik Sistemi: " + (safety ? "AKTİF" : "KAPALI"));
    }

    private void checkDanger() {
        boolean sOn = sharedPref.getBoolean("Mutfak_safety", false);
        boolean oOn = sharedPref.getBoolean("Mutfak_special", false);
        if (sOn && oOn) { txtDangerAlert.setVisibility(View.VISIBLE); startBlinking(); }
        else { txtDangerAlert.setVisibility(View.INVISIBLE); btnSelectMutfak.clearColorFilter(); dangerHandler.removeCallbacksAndMessages(null); }
    }

    private void startBlinking() {
        dangerHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (isRed) btnSelectMutfak.clearColorFilter();
                else btnSelectMutfak.setColorFilter(Color.RED, PorterDuff.Mode.OVERLAY);
                isRed = !isRed; dangerHandler.postDelayed(this, 500);
            }
        }, 500);
    }

    private void updateHomeVisuals() {
        boolean l = swPower.isChecked(), c = swCurtain.isChecked();
        imgRoomIcon.setAlpha(l ? 1.0f : 0.4f);
        if (c) imgRoomIcon.setColorFilter(Color.parseColor("#4E342E"), PorterDuff.Mode.MULTIPLY);
        else if (!l) imgRoomIcon.setColorFilter(Color.GRAY, PorterDuff.Mode.MULTIPLY);
        else imgRoomIcon.clearColorFilter();
    }

    private void saveRoomData(String roomName) {
        SharedPreferences.Editor ed = sharedPref.edit();
        ed.putBoolean(roomName + "_power", swPower.isChecked());
        ed.putBoolean(roomName + "_curtain", swCurtain.isChecked());
        ed.putBoolean(roomName + "_temp", swTemp.isChecked());
        ed.putBoolean(roomName + "_special", swSpecial.isChecked());
        ed.putBoolean(roomName + "_safety", cbSafety.isChecked());
        ed.putString(roomName + "_label", etRoomLabel.getText().toString());
        ed.apply();
        lblInfoLog.setText("Ayarlar Hafızaya Alındı.");
    }

    private void loadRoomData(String roomName) {
        swPower.setChecked(sharedPref.getBoolean(roomName + "_power", true));
        swCurtain.setChecked(sharedPref.getBoolean(roomName + "_curtain", false));
        swTemp.setChecked(sharedPref.getBoolean(roomName + "_temp", false));
        swSpecial.setChecked(sharedPref.getBoolean(roomName + "_special", false));
        cbSafety.setChecked(sharedPref.getBoolean(roomName + "_safety", false));
        etRoomLabel.setText(sharedPref.getString(roomName + "_label", ""));
        updateHomeVisuals();
    }
}