package com.example.myapplication;

import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    CheckBox checkBox;
    CheckBox checkKitap;
    CheckBox checkSpor;
    Button btnGoster;

    TextView txtSonuc;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        checkSpor=findViewById(R.id.checkSpor);
        checkKitap=findViewById(R.id.checkKitap);
        checkBox =findViewById(R.id.checkBox);
        btnGoster=findViewById(R.id.btnGoster);
        txtSonuc=findViewById(R.id.textSonuc);

         btnGoster.setOnClickListener(v ->
         {
             String sonuc ="Seçilenler: ";
             if(checkBox.isChecked()){
                 sonuc+="Müzik";
             }
             if(checkKitap.isChecked()){
                 sonuc+="Kitap ";
             }
             if(checkSpor.isChecked()){
                 sonuc+="spor ";
             }
             if(!checkBox.isChecked()&& !checkKitap.isChecked() && !checkSpor.isChecked()){
                 sonuc= "hıcbır sey yapılmadı";
             }
             txtSonuc.setText(sonuc);
         });
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}